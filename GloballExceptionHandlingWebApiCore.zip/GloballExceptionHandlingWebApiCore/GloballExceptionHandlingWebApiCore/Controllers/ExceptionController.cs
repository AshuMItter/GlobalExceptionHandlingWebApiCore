﻿using Microsoft.AspNetCore.Mvc;

namespace GloballExceptionHandlingWebApiCore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ExceptionController : Controller
    {
        [HttpGet(Name = "GetException")]
        // 
        public IEnumerable<IActionResult> Get()
        {
            
            throw new Exception("Something Went Wrong");
        }
    }
}
